const mongoose = require('mongoose');
const linkSchema = new mongoose.Schema({
        
       userId: {
             type: mongoose.Schema.Types.ObjectId,
             ref: "users"
           },
        linkTitle: {
            type: String,
           
        },
        linkUrl: {
            type: String,
           
        },
        linkLogo: {
            type: String,
            
        },
        type:{
            enum:['socia;']
        },
        status: {
            type: String,
            enum: ["active", "inactive"],
            default: "active"
        }

}, {
    timestamps: true,
    // toJSON: {
    //     virtuals: false,
    //     transform: function (doc, ret) {
    //         if (ret.links && Array.isArray(ret.links)) {
    //             ret.links.forEach(link => {
    //                 delete link.id;
    //             });
    //         }
    //         return ret;
    //     }
    // },
    // toObject: {
    //     virtuals: false,
    //     transform: function (doc, ret) {
    //         if (ret.links && Array.isArray(ret.links)) {
    //             ret.links.forEach(link => {
    //                 delete link.id;
    //             });
    //         }
    //         return ret;
    //     }
    // }
});
module.exports = linkSchema