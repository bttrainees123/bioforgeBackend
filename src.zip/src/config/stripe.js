//for local
// module.exports = {
//     successUrl: 'http://192.168.0.22:3500/payment_success',
//     cancelUrl: 'http://192.168.0.22:3500/payment_failed',

// };
// for development

module.exports = {
    successUrl: 'https://credoindeumapp.com/payment_success',
    cancelUrl: 'https://credoindeumapp.com/payment_failed',
};
