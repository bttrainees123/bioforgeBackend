
module.exports = {
    background: 'https://credoindeumapp.com/images/btnbg.png',
    logo: 'https://credoindeumapp.com/images/logo.png',
};
