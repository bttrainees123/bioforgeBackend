const linkModel = require('../../model/link.model');
const { default: mongoose } = require("mongoose");
const userModel = require('../../model/user.model');

const linkService = {}

linkService.add = async (request) =>{
  request.body.userId = request.auth._id;
  const data = await linkModel.create(request.body);
  return data;
  
}
linkService.update = async (request) => {
    await linkModel.findByIdAndUpdate({ _id: new mongoose.Types.ObjectId(request.body._id) }, request.body);
    return
}
linkService.delete = async (request) =>{
    await linkModel.findByIdAndDelete({_id:new mongoose.Types.ObjectId(request?.query?._id)})
}
linkService.updateStatus = async (request)=>{
    const linkUpdate = await linkModel.findOne({_id:new mongoose.Types.ObjectId(request?.query?._id)});
    if(linkUpdate.status === 'active'){
        await linkModel.findByIdAndUpdate({_id:new mongoose.Types.ObjectId(request?.query?._id)},{status:"inactive"})
    }
    else {
        await linkModel.findByIdAndUpdate({_id:new mongoose.Types.ObjectId(request?.query?._id)},{status:'active'})
    } 
}
linkService.get = async (request) => {
    const userId = request?.auth?._id;
    return await linkModel.aggregate([
        {
            $match: {
                userId: new mongoose.Types.ObjectId(userId),
                status: 'active'
            }
        },
        {
            $project:{
                _id:0,
                linkTitle:1,
                linkUrl:1,
                linkLogo:1,
                status:1
            }
        }
    ]);
}

module.exports = linkService;